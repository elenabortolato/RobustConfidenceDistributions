ks= function (x, y, ...,alternative = c("two.sided", "less", 
                                        "greater")  ){
  #if(is.null(alternative)) alternative="two.sided"
  alternative <- match.arg(alternative)
  DNAME <- deparse1(substitute(x))
  x <- x[!is.na(x)]
  n <- length(x)
  if (n < 1L)    stop("not enough 'x' data")
  
  DNAME <- paste(DNAME, "and", deparse1(substitute(y)))
  y <- y[!is.na(y)]
  n.x <- as.double(n)
  n.y <- length(y)
  if (n.y < 1L) 
    stop("not enough 'y' data")
  
  n <- n.x * n.y/(n.x + n.y)
  w <- c(x, y)
  w
  z <- cumsum(ifelse(order(w) <= n.x, 1/n.x, -1/n.y))
  
  STATISTIC <- switch(alternative, two.sided = max(abs(z)), 
                      greater = max(z), less = -min(z))
  
  
  if (length(unique(x)) < n) {
    warning("ties should not be present for the Kolmogorov-Smirnov test")
    TIES <- TRUE
  }
  
  names(STATISTIC) <- switch(alternative, two.sided = "D", 
                             greater = "D^+", less = "D^-")
  
  RVAL <- list(statistic = STATISTIC)
  #class(RVAL) <- "htest"
  return(RVAL)
}



#install.packages("transport")
library(transport)
 

# function that transforms the output of a Confidencce Distribution CD accapt reject to a confidence density cd
#ndens: number of points in which the density is evaluated
#from to : suòpport of the density evaluation
#values: values from the CD
#bw bandwith of the kernel density 
to_cd=function(values, ndens=1000, from=NULL, to=NULL, bw=0.2 ){
  values=values[!is.na(values)]
  FF=density(values, n=ndens, from=from,bw=bw,to=to,kernel="rectangular")
  # transform the density in such a way that is in 01 monotonic increasing
  # for(i in 2:length(FF$y)){    if(FF$y[i]<FF$y[i-1]) FF$y[i]=FF$y[i-1]   }
  Fcheck=  (FF$y-min(FF$y))
  Fcheck=Fcheck /max(Fcheck)
  #define a sequence of nominal levels for the quantiles for the cd
  quantiles= seq(0,1, length=round(ndens*0.5))
  #find the corresponding points
  qq=sapply(quantiles, function (x) which.min(abs(Fcheck-x)))
  qq=unlist(qq)
  theta=FF$x[qq]
  return(list( theta=theta  ))
}


#################################################################################################################



#simulations for CD

sim=function(ref, N=100, TIMES=2){
  #proposal for the parameter and for generating from the model
  proposal = function (n = 1)     runif(n, 0, ref)
  ygen = function(th,NN=N*TIMES)   rnorm(NN, th, 1)
   
  # results CD KS
  resks0 = matrix(0, nrow = 1000, ncol=2)
  resks5=resks10=resks15=resks20=resks0
  # results CD W
  resw0 = matrix(0, nrow = 1000, ncol=2)
  resw5=resw10=resw15=resw20=resw0
  
  estks=rep(NA,1000)
  estw=rep(NA,1000)
  estks5=estks10=estks15=estks20=estks
  estw5=estw10=estw15=estw20=estw
  
  k=1 
  for (k in k:1000){
    print(k)
    ycau = abs(rcauchy(N))
    ycau = ycau[order((ycau), decreasing = T)]
    #  CD KS
    y0 = c(rnorm(N*TIMES, 1, 1))
    yref = rnorm(N*TIMES,ref, 1)
    s0 = ks(y0, yref, alternative = "two.sided")$statistic
    s0W =  wasserstein1d(y0, yref)
    thetas = NULL
    y5 = c(y0[1:(95*TIMES)], ycau[1:(5*TIMES)])
    #yref = rnorm(100,median(y5), 1)
    s05 = ks(y5, yref, alternative = "two.sided")$statistic
    s05W =  wasserstein1d(y5, yref)
    thetas_cont5 = NULL
    y10 = c(y0[1:(90*TIMES)], ycau[1:(10*TIMES)])
    #yref = rnorm(100,median(y10), 1)
    s010 = ks(y10, yref, alternative = "two.sided")$statistic
    s010W = wasserstein1d(y10, yref)
    thetas_cont10 = NULL
    y15 = c(y0[1:(85*TIMES)], ycau[1:(15*TIMES)])
    #yref = rnorm(100,median(y15), 1)
    s015 = ks(y15, yref, alternative = "two.sided")$statistic
    s015W =  wasserstein1d(y15, yref)
    thetas_cont15 = NULL
    y20 = c(y0[1:(TIMES*80)], ycau[1:(TIMES*20)])
    #yref = rnorm(100,median(y20), 1)
    s020 = ks(y20, yref, alternative = "two.sided")$statistic
    s020W = wasserstein1d(y20, yref)
    thetas_cont20 = NULL
    
    # CD W
    thetasW = NULL
    thetas_cont5W = NULL
    thetas_cont10W = NULL
    thetas_cont15W = NULL
    thetas_cont20W = NULL
    
    for (j in 1:5000) {
      th = proposal()
      ynew = ygen(th)
      #KS DIST OBS
      ks_curr=ks(ynew, yref, alternative = "two.sided")$statistic
      if (ks_curr <= s0)
        thetas = c(thetas, th)
      if (ks_curr <= s05)
        thetas_cont5 = c(thetas_cont5, th)
      if (ks_curr <= s010)
        thetas_cont10 = c(thetas_cont10, th)
      if (ks_curr<= s015)
        thetas_cont15 = c(thetas_cont15, th)
      if (ks_curr<= s020)
        thetas_cont20 = c(thetas_cont20, th)
      #W DIST OBS
      
      w_curr=wasserstein1d(ynew, yref) 
      #save the value if simulated dist > dobs
      if (w_curr <= s0W)
        thetasW = c(thetasW, th)
      if (w_curr <= s05W)
        thetas_cont5W = c(thetas_cont5W, th)
      if (w_curr <= s010W)
        thetas_cont10W = c(thetas_cont10W, th)
      if (w_curr<= s015W)
        thetas_cont15W = c(thetas_cont15W, th)
      if (w_curr<= s020W)
        thetas_cont20W = c(thetas_cont20W, th)
    }
    
    thetas = to_cd(thetas,ndens = 1000, from = -0, to = ref)
    thetas_cont5 = to_cd(values = thetas_cont5, ndens = 1000,from = -0, to = ref)
    thetas_cont10 = to_cd(values = thetas_cont10, ndens = 1000,from = -0, to = ref)
    thetas_cont15 = to_cd(values = thetas_cont15,ndens = 1000, from = -0, to = ref)
    thetas_cont20 = to_cd(values=thetas_cont20,ndens = 1000, from = -0, to = ref)
    #store endpoints of Confidence Intervals
    resks0[k,]=quantile(thetas$theta,c(0.05,0.95))
    resks5[k,]=quantile(thetas_cont5$theta,c(0.05,0.95))
    resks10[k,]=quantile(thetas_cont10$theta,c(0.05,0.95))
    resks15[k,]=quantile(thetas_cont15$theta,c(0.05,0.95))
    resks20[k,]=quantile(thetas_cont20$theta,c(0.05,0.95))
    
    
    estks5[k]=quantile(thetas_cont5$theta,c(0.5))
    estks10[k]=quantile(thetas_cont10$theta,c(0.5))
    estks15[k]=quantile(thetas_cont15$theta,c(0.5))
    estks20[k]=quantile(thetas_cont20$theta,c(0.5))
    estks[k]=quantile(thetas$theta,c(0.5))
    
    
    thetasW = to_cd(values = thetasW, from = -0, to = ref)
    thetas_cont5W = to_cd(values =thetas_cont5W, from = -0, to = ref)
    thetas_cont10W = to_cd(values =thetas_cont10W, from = -0, to = ref)
    thetas_cont15W = to_cd(values =thetas_cont15W, from = 0, to = ref)
    thetas_cont20W = to_cd(values =thetas_cont20W, from = -0, to = ref)
    #store endpoints of Confidence Intervals
    resw0[k,]=quantile(thetasW$theta,c(0.05,0.95))
    resw5[k,]=quantile(thetas_cont5W$theta,c(0.05,0.95))
    resw10[k,]=quantile(thetas_cont10W$theta,c(0.05,0.95))
    resw15[k,]=quantile(thetas_cont15W$theta,c(0.05,0.95))
    resw20[k,]=quantile(thetas_cont20W$theta,c(0.05,0.95))
    
    
    estw5[k]=quantile(thetas_cont5W$theta,c(0.5))
    estw10[k]=quantile(thetas_cont10W$theta,c(0.5))
    estw15[k]=quantile(thetas_cont15W$theta,c(0.5))
    estw20[k]=quantile(thetas_cont20W$theta,c(0.5))
    estw[k]=quantile(thetasW$theta,c(0.5))
    
    
    
    K=k
    EST=cbind(estks,estks5,estks10,estks15,estks20,estw,estw5,estw10,estw15,estw20)
    
    TAB= matrix(c(
      mean(sapply (1:K ,function (k)resks0[k,1]<1 && resks0[k,2]>1)),
      mean(sapply (1:K ,function (k)resks5[k,1]<1 && resks5[k,2]>1)),
      mean(sapply (1:K ,function (k)resks10[k,1]<1 && resks10[k,2]>1)),
      mean(sapply (1:K ,function (k)resks15[k,1]<1 && resks15[k,2]>1)),
      mean(sapply (1:K ,function (k)resks20[k,1]<1 && resks20[k,2]>1)),
      
      mean(sapply (1:K ,function (k)resw0[k,1]<1 && resw0[k,2]>1)),
      mean(sapply (1:K ,function (k)resw5[k,1]<1 && resw5[k,2]>1)),
      mean(sapply (1:K ,function (k)resw10[k,1]<1 && resw10[k,2]>1)),
      mean(sapply (1:K ,function (k)resw15[k,1]<1 && resw15[k,2]>1)),
      mean(sapply (1:K ,function (k)resw20[k,1]<1 && resw20[k,2]>1))),
      ncol=2)
    
    colnames(TAB)=c("KS", "W")
    rownames(TAB)=c(0,5,10,15, 20)
    print(TAB)
    
  }
  return(list(CI=TAB, EST=EST))
}

set.seed(9975311)
#N=100
RIS10=sim(10,1)
RIS8=sim(8,1)
RIS6=sim(6,1)
RIS4=sim(4,1)
RIS3=sim(3,1)


set.seed(9975311)
#N=20
RIS10_20=sim(10,0.2)
RIS8_20=sim(8,0.2)
RIS6_20=sim(6,0.2)
RIS4_20=sim(4,0.2)
RIS3_20=sim(3,0.2)


ris_ks_w_100=list(ris10=RIS10, ris8=RIS8, ris6=RIS6, ris4=RIS4, ris3=RIS3)
saveRDS(ris_ks_w_100, "ris_ks_w_100.RDS")
 
ris_ks_w_20=list(ris10=RIS10_20, ris8=RIS8_20, ris6=RIS6_20, ris4=RIS4_20, ris3=RIS3_20)
saveRDS(ris_ks_w_20, "ris_ks_w_20.RDS")


#############################################
# ABC SIMULATIONS

simABC=function(ref=10, N=100, TIMES=1){
  #proposal for the parameter and for generating from the model
  proposal = function (n = 1)     runif(n, 0, ref)
  ygen = function(th,NN=N*TIMES)   rnorm(NN, th, 1)
  
  # results CD KS
  resks0 = matrix(0, nrow = 1000, ncol=2)
  resks5=resks10=resks15=resks20=resks0
  # results CD W
  resw0 = matrix(0, nrow = 1000, ncol=2)
  resw5=resw10=resw15=resw20=resw0
  
  estks=rep(NA,1000)
  estw=rep(NA,1000)
  estks5=estks10=estks15=estks20=estks
  estw5=estw10=estw15=estw20=estw
  
  k=1 
  for (k in k:1000){
    diks=NULL
    diw=NULL
    diks5=diks10=diks15=diks20=NULL
    diw5=diw10=diw15=diw20=NULL
    print(k)
     
     
    ycau = abs(rcauchy(N))
    ycau = ycau[order((ycau), decreasing = T)]
    #  CD KS
    y0 = c(rnorm(N*TIMES, 1, 1))
    
    thetas = NULL
    y5 = c(y0[1:(95*TIMES)], ycau[1:(5*TIMES)])
    y10 = c(y0[1:(90*TIMES)], ycau[1:(10*TIMES)])
    y15 = c(y0[1:(85*TIMES)], ycau[1:(15*TIMES)])
    y20 = c(y0[1:(TIMES*80)], ycau[1:(TIMES*20)])
     
    
    for (j in 1:1000) {
      th = proposal()
      thetas=c(thetas,th)
      ynew = ygen(th)
      #KS DIST OBS
      diks=c(diks,abs(ks(ynew, y0, alternative = "two.sided")$statistic))
      diks5=c(diks5,abs(ks(ynew, y5, alternative = "two.sided")$statistic))
      diks10=c(diks10,abs(ks(ynew, y10, alternative = "two.sided")$statistic))
      diks15=c(diks15,abs(ks(ynew, y15, alternative = "two.sided")$statistic))
      diks20=c(diks20,abs(ks(ynew, y20, alternative = "two.sided")$statistic))
      
      #W DIST OBS
      
      diw=c(diw,abs(wasserstein1d(ynew, y0)))
      diw5=c(diw5,abs(wasserstein1d(ynew, y5)))
      diw10=c(diw10,abs(wasserstein1d(ynew, y10)))
      diw15=c(diw15,abs(wasserstein1d(ynew, y15)))#save the value if simulated dist > dobs
      diw20=c(diw20,abs(wasserstein1d(ynew, y20)))
    }
    
    #store endpoints of Confidence Intervals
    resks0[k,]=quantile(thetas[order(abs(diks),decreasing = F)][1:500],c(0.05,0.95))
    resks5[k,]=quantile(thetas[order(abs(diks5),decreasing = F)][1:500],c(0.05,0.95))
    resks10[k,]=quantile(thetas[order(abs(diks10),decreasing = F)][1:500],c(0.05,0.95))
    resks15[k,]=quantile(thetas[order(abs(diks15),decreasing = F)][1:500],c(0.05,0.95))
    resks20[k,]=quantile(thetas[order(abs(diks20),decreasing = F)][1:500],c(0.05,0.95))
    
    
    estks5[k]=quantile(thetas[order(abs(diks),decreasing = F)][1:500],c(0.5))
    estks10[k]=quantile(thetas[order(abs(diks5),decreasing = F)][1:500],c(0.5))
    estks15[k]=quantile(thetas[order(abs(diks10),decreasing = F)][1:500],c(0.5))
    estks20[k]=quantile(thetas[order(abs(diks15),decreasing = F)][1:500],c(0.5))
    estks[k]=quantile(thetas[order(abs(diks20),decreasing = F)][1:500],c(0.5))
    
    
    #store endpoints of Confidence Intervals
    resw0[k,]=quantile(thetas[order(abs(diw),decreasing = F)][1:500],c(0.05,0.95))
    resw5[k,]=quantile(thetas[order(abs(diw5),decreasing = F)][1:500],c(0.05,0.95))
    resw10[k,]=quantile(thetas[order(abs(diw10),decreasing = F)][1:500],c(0.05,0.95))
    resw15[k,]=quantile(thetas[order(abs(diw15),decreasing = F)][1:500],c(0.05,0.95))
    resw20[k,]=quantile(thetas[order(abs(diw20),decreasing = F)][1:500],c(0.05,0.95))
    
    
    estw5[k]=quantile(thetas[order(abs(diw5),decreasing = F)][1:500],c(0.5))
    estw10[k]=quantile(thetas[order(abs(diw10),decreasing = F)][1:500],c(0.5))
    estw15[k]=quantile(thetas[order(abs(diw15),decreasing = F)][1:500],c(0.5))
    estw20[k]=quantile(thetas[order(abs(diw20),decreasing = F)][1:500],c(0.5))
    estw[k]=quantile(thetas[order(abs(diw),decreasing = F)][1:500],c(0.5))
    
    
    
    K=k
    EST=cbind(estks,estks5,estks10,estks15,estks20,estw,estw5,estw10,estw15,estw20)
    
    TAB= matrix(c(
      mean(sapply (1:K ,function (k)resks0[k,1]<1 && resks0[k,2]>1), na.rm=T),
      mean(sapply (1:K ,function (k)resks5[k,1]<1 && resks5[k,2]>1),na.rm=T),
      mean(sapply (1:K ,function (k)resks10[k,1]<1 && resks10[k,2]>1),na.rm=T),
      mean(sapply (1:K ,function (k)resks15[k,1]<1 && resks15[k,2]>1),na.rm=T),
      mean(sapply (1:K ,function (k)resks20[k,1]<1 && resks20[k,2]>1),na.rm=T),
      
      mean(sapply (1:K ,function (k)resw0[k,1]<1 && resw0[k,2]>1),na.rm=T),
      mean(sapply (1:K ,function (k)resw5[k,1]<1 && resw5[k,2]>1),na.rm=T),
      mean(sapply (1:K ,function (k)resw10[k,1]<1 && resw10[k,2]>1),na.rm=T),
      mean(sapply (1:K ,function (k)resw15[k,1]<1 && resw15[k,2]>1),na.rm=T),
      mean(sapply (1:K ,function (k)resw20[k,1]<1 && resw20[k,2]>1),na.rm=T)),
      ncol=2)
    
    colnames(TAB)=c("KS", "W")
    rownames(TAB)=c(0,5,10,15, 20)
    print(TAB)
    
    
  }
  return(list(CI=TAB, EST=EST))
}

set.seed(9975311)
#N=20
RIS10_20=simABC(100,0.2,ref = 10)
RIS8_20=simABC(100,0.2,ref = 8)
RIS6_20=simABC(100,0.2,ref = 6)
RIS4_20=simABC(100,0.2,ref=4)
RIS3_20=simABC(100,0.2,ref=3)

set.seed(9975311)
#N=100
RIS10=simABC(100,1,ref = 10)
RIS8=simABC(100,1,ref = 8)
RIS6=simABC(100,1,ref = 6)
RIS4=simABC(100,1,ref=4)
RIS3=simABC(100,1,ref=3)


ris_ks_w_100abc=list(ris10=RIS10, ris8=RIS8, ris6=RIS6, ris4=RIS4, ris3=RIS3)
saveRDS(ris_ks_w_100abc, "ris_ks_w_100abc.RDS")

ris_ks_w_20abc=list(ris10=RIS10_20, ris8=RIS8_20, ris6=RIS6_20, ris4=RIS4_20, ris3=RIS3_20)
saveRDS(ris_ks_w_20abc, "ris_ks_w_20abc.RDS")

