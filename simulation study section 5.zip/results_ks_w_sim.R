# TABLES
# read files CD
ris_ks_w_100=readRDS("ris_ks_w_100.RDS")
ris_ks_w_20=readRDS("ris_ks_w_20.RDS")

RIS10=ris_ks_w_100$ris10
RIS8=ris_ks_w_100$ris8
RIS6=ris_ks_w_100$ris6
RIS4=ris_ks_w_100$ris4
RIS3=ris_ks_w_100$ris3

RIS10_20=ris_ks_w_20$ris10
RIS8_20=ris_ks_w_20$ris8
RIS6_20=ris_ks_w_20$ris6
RIS4_20=ris_ks_w_20$ris4
RIS3_20=ris_ks_w_20$ris3

install.packages("xtable")
xtable::xtable(
  cbind(
    cbind(apply(RIS3$EST,2, function (x) mean(x))[c(1:5)],apply(RIS3$EST,2, function (x) mean(x))[c(6:10)]),
    cbind(apply(RIS4$EST,2, function (x) mean(x))[c(1:5)],apply(RIS4$EST,2, function (x) mean(x))[c(6:10)]),
    cbind(apply(RIS6$EST,2, function (x) mean(x))[c(1:5)],apply(RIS6$EST,2, function (x) mean(x))[c(6:10)]),
    cbind(apply(RIS8$EST,2, function (x) mean(x))[c(1:5)],apply(RIS8$EST,2, function (x) mean(x))[c(6:10)]),
    cbind(apply(RIS10$EST,2, function (x) mean(x))[c(1:5)],apply(RIS10$EST,2, function (x) mean(x))[c(6:10)])))

xtable::xtable(
  cbind(
    cbind(apply(RIS3_20$EST,2, function (x) mean(x))[c(1:5)],apply(RIS3_20$EST,2, function (x) mean(x))[c(6:10)]),
    cbind(apply(RIS4_20$EST,2, function (x) mean(x))[c(1:5)],apply(RIS4_20$EST,2, function (x) mean(x))[c(6:10)]),
    cbind(apply(RIS6_20$EST,2, function (x) mean(x))[c(1:5)],apply(RIS6_20$EST,2, function (x) mean(x))[c(6:10)]),
    cbind(apply(RIS8_20$EST,2, function (x) mean(x))[c(1:5)],apply(RIS8_20$EST,2, function (x) mean(x))[c(6:10)]),
    cbind(apply(RIS10_20$EST,2, function (x) mean(x))[c(1:5)],apply(RIS10_20$EST,2, function (x) mean(x))[c(6:10)])))

############################################à


#READ FILES ABC
ris_ks_w_100=readRDS("ris_ks_w_100abc.RDS")
ris_ks_w_20=readRDS("ris_ks_w_20abc.RDS")

RIS10=ris_ks_w_100$ris10
RIS8=ris_ks_w_100$ris8
RIS6=ris_ks_w_100$ris6
RIS4=ris_ks_w_100$ris4
RIS3=ris_ks_w_100$ris3

RIS10_20=ris_ks_w_20$ris10
RIS8_20=ris_ks_w_20$ris8
RIS6_20=ris_ks_w_20$ris6
RIS4_20=ris_ks_w_20$ris4
RIS3_20=ris_ks_w_20$ris3

install.packages("xtable")
xtable::xtable(
  cbind(
    cbind(apply(RIS3$EST,2, function (x) mean(x))[c(1:5)],apply(RIS3$EST,2, function (x) mean(x))[c(6:10)]),
    cbind(apply(RIS4$EST,2, function (x) mean(x))[c(1:5)],apply(RIS4$EST,2, function (x) mean(x))[c(6:10)]),
    cbind(apply(RIS6$EST,2, function (x) mean(x))[c(1:5)],apply(RIS6$EST,2, function (x) mean(x))[c(6:10)]),
    cbind(apply(RIS8$EST,2, function (x) mean(x))[c(1:5)],apply(RIS8$EST,2, function (x) mean(x))[c(6:10)]),
    cbind(apply(RIS10$EST,2, function (x) mean(x))[c(1:5)],apply(RIS10$EST,2, function (x) mean(x))[c(6:10)])))

xtable::xtable(
  cbind(
    cbind(apply(RIS3_20$EST,2, function (x) mean(x))[c(1:5)],apply(RIS3_20$EST,2, function (x) mean(x))[c(6:10)]),
    cbind(apply(RIS4_20$EST,2, function (x) mean(x))[c(1:5)],apply(RIS4_20$EST,2, function (x) mean(x))[c(6:10)]),
    cbind(apply(RIS6_20$EST,2, function (x) mean(x))[c(1:5)],apply(RIS6_20$EST,2, function (x) mean(x))[c(6:10)]),
    cbind(apply(RIS8_20$EST,2, function (x) mean(x))[c(1:5)],apply(RIS8_20$EST,2, function (x) mean(x))[c(6:10)]),
    cbind(apply(RIS10_20$EST,2, function (x) mean(x))[c(1:5)],apply(RIS10_20$EST,2, function (x) mean(x))[c(6:10)])))

